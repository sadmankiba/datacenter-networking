#!/bin/bash

echo "export PKG_CONFIG_PATH=/usr/lib/x86_64-linux-gnu/pkgconfig/" >> ~/.profile
export PKG_CONFIG_PATH=/usr/lib/x86_64-linux-gnu/pkgconfig/
dpkg -i libdpkg-perl_1.18.25_all.deb 
dpkg -i pkg-config_0.29-4+b1_amd64.deb 
dpkg -i libnl-3-200_3.2.27-2_amd64.deb
dpkg -i libnl-3-dev_3.2.27-2_amd64.deb
dpkg -i libtcmalloc-minimal4_2.5-2.2_amd64.deb
dpkg -i libunwind8_1.1-4.1_amd64.deb
dpkg -i libcurl3_7.52.1-5+deb9u12_amd64.deb
dpkg -i curl_7.52.1-5+deb9u12_amd64.deb
dpkg -i libgoogle-perftools4_2.5-2.2_amd64.deb
dpkg -i google-perftools_2.5-2.2_all.deb
dpkg -i libnl-genl-3-200_3.2.27-2_amd64.deb
dpkg -i libnl-genl-3-dev_3.2.27-2_amd64.deb
dpkg -i python-pycparser_2.17-2_all.deb
dpkg -i python-cffi-backend_1.9.1-2_amd64.deb
dpkg -i python-cffi_1.9.1-2_all.deb
dpkg -i libbz2-dev_1.0.6-8.1_amd64.deb
dpkg -i ed_1.10-2.1_amd64.deb
dpkg -i cscope_15.8b-2_amd64.deb
dpkg -i libnl-route-3-200_3.2.27-2_amd64.deb
dpkg -i libnl-route-3-dev_3.2.27-2_amd64.deb
dpkg -i python-ipaddress_1.0.17-1_all.deb
dpkg -i python-pyparsing_2.1.10+dfsg1-1_all.deb
dpkg -i libc-ares2_1.12.0-1+deb9u1_amd64.deb
dpkg -i libc-ares-dev_1.12.0-1+deb9u1_amd64.deb
dpkg -i libgmp10_6.1.2+dfsg-1_amd64.deb 
dpkg -i libgmpxx4ldbl_6.1.2+dfsg-1_amd64.deb 
dpkg -i libxml-sax-base-perl_1.07-1_all.deb 
dpkg -i libxml-namespacesupport-perl_1.11-1_all.deb 
dpkg -i libxml-sax-perl_0.99+dfsg-2_all.deb 
dpkg -i libxml-libxml-perl_2.0128+dfsg-1+deb9u1_amd64.deb 
dpkg -i libxml-simple-perl_2.22-1_all.deb 
dpkg -i emacsen-common_2.0.8_all.deb 
dpkg -i libtext-iconv-perl_1.7-5+b4_amd64.deb 
dpkg -i dictionaries-common_1.27.2_all.deb 
dpkg -i libaspell15_0.60.7~20110707-3+b2_amd64.deb 
dpkg -i libaspell-dev_0.60.7~20110707-3+b2_amd64.deb 
dpkg -i aspell_0.60.7~20110707-3+b2_amd64.deb 
dpkg -i aspell-en_2016.11.20-0-0.1_all.deb 
dpkg -i libelf1_0.168-1_amd64.deb 
dpkg -i libelf-dev_0.168-1_amd64.deb 
dpkg -i python-setuptools_33.1.1-1_all.deb 
dpkg -i libxapian30_1.4.3-2+deb9u3_amd64.deb 
dpkg -i libllvm3.9_3.9.1-9_amd64.deb 
dpkg -i libclang1-3.9_3.9.1-9_amd64.deb 
dpkg -i doxygen_1.8.13-4+b1_amd64.deb 
dpkg -i python-ply_3.9-1_all.deb 
dpkg -i python3-pyparsing_2.1.10+dfsg1-1_all.deb 
dpkg -i python3-six_1.10.0-3_all.deb 
dpkg -i python3-packaging_16.8-1_all.deb 
dpkg -i libjudydebian1_1.0.5-5_amd64.deb 
dpkg -i libjudy-dev_1.0.5-5_amd64.deb 
dpkg -i python-enum34_1.1.6-1_all.deb 
dpkg -i python-vcversioner_2.16.0.0-1_all.deb 
dpkg -i doxypy_0.4.2-1.1_all.deb
dpkg -i libcli1.9_1.9.7-2_amd64.deb 
dpkg -i libcli-dev_1.9.7-2_amd64.deb 

pip install ctypesgen-1.0.2-py2.py3-none-any.whl 
pip3 install ctypesgen-1.0.2-py2.py3-none-any.whl 
pip3 install setuptools-44.0.0-py2.py3-none-any.whl 

tar zxvf crc16-0.1.1.tar.gz 
cd crc16-0.1.1
python setup.py build
sudo python setup.py install
cd ..
tar zxvf jsl-0.2.4.tar.gz 
cd jsl-0.2.4
sudo python setup.py install
sudo python3 setup.py install
cd ../
tar zxvf coverage-4.5.2.tar.gz 
cd coverage-4.5.2
sudo python setup.py install
cd ..
tar zxvf Cython-0.29.3.tar.gz 
cd Cython-0.29.3
sudo python setup.py install
cd ..
tar zxvf futures-3.2.0.tar.gz 
cd futures-3.2.0
sudo python setup.py install
cd ..
tar zxvf wheel-0.32.3.tar.gz 
cd wheel-0.32.3
sudo python setup.py install
sudo python3 setup.py install
cd ../
tar zxvf six-1.12.0.tar.gz 
cd six-1.12.0
sudo python setup.py install
cd ../
tar zxvf jsonschema-2.6.0.tar.gz 
cd jsonschema-2.6.0
sudo python setup.py install
cd ../
tar zxvf simplejson-3.16.0.tar.gz 
cd simplejson-3.16.0
sudo python setup.py install
cd ..
tar zxvf Tenjin-1.1.1.tar.gz 
cd Tenjin-1.1.1
sudo python setup.py install
cd ..

tar zxvf graphviz_2.40.1.orig.tar.gz 
cd graphviz-2.40.1/
./configure
make
make install
cd ..
tar zxvf boost_1_67_0.tar.gz 
cd boost_1_67_0
./bootstrap.sh --prefix=/usr
./b2 --with-thread --with-test --with-system --with-graph --with-iostreams install
ldconfig
cd ..
tar zxvf thrift-0.13.0.tar.gz 
cd thrift-0.13.0
./configure --without-lua PY_PREFIX=/usr/local
make
make install
ldconfig
cd ..
tar zxvf libnl3_3.2.27.orig.tar.gz 
ls -ltr
cd libnl-3.2.27/
./configure
make
make install
ldconfig
cd ..
tar zxvf protobuf-python-3.6.1.tar.gz
cd protobuf-3.6.1
./autogen.sh
./configure --prefix=/usr
make
make install
cd python
python setup.py build
python setup.py install
cd ../..
tar xzvf zlib_1.2.8.dfsg.orig.tar.gz
cd zlib-1.2.8
./configure
make
make install
cd ..
tar zxvf grpc.tar.gz
cd grpc
make prefix=/usr
make install prefix=/usr
python setup.py build
python setup.py install
cd ..
tar zxvf PI.tar.gz
cd PI
./autogen.sh
./configure --with-proto --without-internal-rpc --without-cli --prefix=/usr --with-boost-libdir=/usr/lib
make -j4
make install
cd ..
tar zxvf pysubnettree-0.35.tar.gz
cd pysubnettree-0.35
python3 setup.py install
python setup.py install
cd ..
